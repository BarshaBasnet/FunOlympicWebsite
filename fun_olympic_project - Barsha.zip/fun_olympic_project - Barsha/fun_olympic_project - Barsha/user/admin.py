from django.contrib import admin

from .models import User, VideoWatched

admin.site.register(User)
admin.site.register(VideoWatched)
