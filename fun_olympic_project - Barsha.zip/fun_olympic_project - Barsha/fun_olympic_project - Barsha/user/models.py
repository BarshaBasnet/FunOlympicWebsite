from django.db import models
from django.contrib.auth.base_user import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from django.utils.translation import gettext_lazy as _

from django_countries.fields import CountryField

from .managers import CustomUserManager


class User(AbstractBaseUser, PermissionsMixin):
    """
    email and password are required. Other fields are optional.
    """

    full_name = models.CharField(max_length=150)
    email = models.EmailField(unique=True,
                              error_messages={
                                  'unique': _("Email already taken."),
                              },
                              )
    country = CountryField()
    is_staff = models.BooleanField('staff status', default=False)
    is_active = models.BooleanField('active', default=True)
    is_verified = models.BooleanField(default=True)
    total_watched_videos = models.IntegerField(default=0)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    def __str__(self):
        return self.email

    @property
    def get_watched_video_count(self, *args, **kwargs):
        return VideoWatched.objects.filter(user=self).count()


class VideoWatched(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    video = models.ForeignKey('video_app.Video', on_delete=models.CASCADE)
