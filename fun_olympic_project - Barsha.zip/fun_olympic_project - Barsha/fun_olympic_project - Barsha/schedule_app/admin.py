from django.contrib import admin

from .models import GameSchedule

admin.site.register(GameSchedule)
